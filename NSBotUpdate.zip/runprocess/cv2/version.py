opencv_version = "4.7.0.72"
contrib = False
headless = False
rolling = False
ci_build = True